import os
import requests
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables from .env file
load_dotenv()

# Get the API key from the environment variable
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

if not NEWS_API_KEY:
    raise ValueError("Missing NEWS_API_KEY. Please add it to the .env file.")

# Function to fetch news for a specific date and topic
def get_news_for_date_and_topic(date, topic):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": topic,  # Use topic instead of generic "news"
        "from": date,
        "to": date,
        "sortBy": "popularity",
        "apiKey": NEWS_API_KEY,
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()  # Will raise HTTPError for bad responses
        data = response.json()
        articles = data.get("articles", [])
        return articles
    except requests.exceptions.RequestException as e:
        print(f"Error fetching news: {e}")
        return []

# Validate date format and check if it's a real date
def is_valid_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")  # Try to convert the string to a date
        return True
    except ValueError:
        return False

# Chatbot functionality
def chatbot():
    print("Welcome to the improved News Chatbot!")
    print("Ask me for news by entering a date in YYYY-MM-DD format.")
    print("You can also specify a topic (e.g., 'sports', 'technology').")
    print("Type 'exit' to quit.\n")

    while True:
        user_input = input("You: ").strip()
        
        if user_input.lower() == 'exit':
            print("Chatbot: Goodbye! Have a great day!")
            break

        # Check if the input includes a date
        parts = user_input.split()
        date_input = None
        topic_input = "news"  # Default topic
        
        # Check for a date in the user input
        for part in parts:
            if is_valid_date(part):
                date_input = part
                parts.remove(part)
                break
        
        # The remaining part is considered the topic
        if parts:
            topic_input = " ".join(parts)

        # If no valid date, prompt the user
        if not date_input:
            print("Chatbot: Please enter a valid date in YYYY-MM-DD format.")
            continue

        news_articles = get_news_for_date_and_topic(date_input, topic_input)
        if news_articles:
            print(f"Chatbot: Here are the top news articles for {topic_input} on {date_input}:\n")
            for idx, article in enumerate(news_articles[:5], start=1):  # Top 5 articles
                print(f"{idx}. {article['title']}")
                print(f"   Source: {article['source']['name']}")
                print(f"   URL: {article['url']}\n")
        else:
            print(f"Chatbot: Sorry, I couldn't find any news for {topic_input} on {date_input}.")

# Run the chatbot
if __name__ == "__main__":
    chatbot()
