import os
import requests
from dotenv import load_dotenv
from flask import Flask, render_template, request, jsonify
from datetime import datetime

# Load environment variables from .env file
load_dotenv()

# Get the API key from the environment variable
NEWS_API_KEY = os.getenv("NEWS_API_KEY")

if not NEWS_API_KEY:
    raise ValueError("Missing NEWS_API_KEY. Please add it to the .env file.")

# Function to fetch news for a specific date and topic
def get_news_for_date_and_topic(date, topic):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": topic,
        "from": date,
        "to": date,
        "sortBy": "popularity",
        "apiKey": NEWS_API_KEY,
    }

    try:
        response = requests.get(url, params=params)
        response.raise_for_status()
        data = response.json()
        articles = data.get("articles", [])
        return articles
    except requests.exceptions.RequestException as e:
        return []

# Validate date format and check if it's a real date
def is_valid_date(date_str):
    try:
        datetime.strptime(date_str, "%Y-%m-%d")
        return True
    except ValueError:
        return False

# Create a Flask web application
app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/get_news", methods=["POST"])
def get_news():
    date_input = request.form.get("date")
    topic_input = request.form.get("topic", "news")

    if not date_input or not is_valid_date(date_input):
        return jsonify({"error": "Invalid date format. Please use YYYY-MM-DD."})

    news_articles = get_news_for_date_and_topic(date_input, topic_input)
    if news_articles:
        articles = [{"title": article["title"], "source": article["source"]["name"], "url": article["url"]} for article in news_articles[:5]]
        return jsonify({"articles": articles})
    else:
        return jsonify({"error": "No news found for the specified date and topic."})

if __name__ == "__main__":
    app.run(debug=True)
